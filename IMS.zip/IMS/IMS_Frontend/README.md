# IMS React Frontend
Simple React frontend for the Inventory Management System.

Run:
npm install
npm run dev

Open: http://localhost:5173

Backend:
Inventory http://localhost:8083
Material http://localhost:8082
Vendor http://localhost:8087

Features: service health, purchase entry, vendor/category dropdowns, category-based type/unit loading, purchase save, purchase report.
