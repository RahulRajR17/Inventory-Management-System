import React, { useEffect, useState } from "react";
import { api } from "../api";

export default function PurchaseReport() {

  const [vendors, setVendors] = useState([]);
  const [vendor, setVendor] = useState("");
  const [selectedVendor, setSelectedVendor] = useState(null);

  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.getVendors()
      .then(v => setVendors(v || []))
      .catch(e => setError(e.message));
  }, []);

  function handleVendorChange(e) {
    const vendorName = e.target.value;

    setVendor(vendorName);

    const selected = vendors.find(
      v => v.vendorName === vendorName
    );

    setSelectedVendor(selected || null);
  }

  async function report(e) {
    e.preventDefault();

    setError("");
    setRows([]);

    if (!vendor || !fromDate || !toDate) {
      setError("Please select vendor and both dates.");
      return;
    }

    if (fromDate > toDate) {
      setError("From date cannot be after To date.");
      return;
    }

    setLoading(true);

    try {
      const data = await api.getPurchaseDetails({
        fromDate,
        toDate,
        vendorName: vendor
      });

      setRows(data || []);

    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section>

      <h2>Purchase Report</h2>

      <p className="subtitle">
        Search purchase records by vendor and date.
      </p>


      {/* SEARCH FORM */}
      <form className="card report-form" onSubmit={report}>

        <label>
          Vendor *

          <select
            value={vendor}
            onChange={handleVendorChange}
          >
            <option value="">
              -- Select Vendor --
            </option>

            {vendors.map(v => (
              <option
                key={v.vendorId}
                value={v.vendorName}
              >
                {v.vendorName}
              </option>
            ))}

          </select>
        </label>


        <label>
          From Date *

          <input
            type="date"
            value={fromDate}
            onChange={e => setFromDate(e.target.value)}
          />
        </label>


        <label>
          To Date *

          <input
            type="date"
            value={toDate}
            onChange={e => setToDate(e.target.value)}
          />
        </label>


        <button
          type="submit"
          className="primary"
          disabled={loading}
        >
          {loading ? "Loading..." : "Generate Report"}
        </button>

      </form>


      {error && (
        <div className="error">
          {error}
        </div>
      )}


      {/* VENDOR DETAILS */}
      {selectedVendor && (
        <div className="card vendor-details">

          <h3>Vendor Details</h3>

          <div className="vendor-info-grid">

            <div>
              <strong>Address</strong>
              <p>
                {selectedVendor.vendorAddress || "N/A"}
              </p>
            </div>

            <div>
              <strong>Contact Number</strong>
              <p>
                {selectedVendor.contactNumber || "N/A"}
              </p>
            </div>

            <div>
              <strong>Contact Person</strong>
              <p>
                {selectedVendor.contactPerson || "N/A"}
              </p>
            </div>

          </div>

        </div>
      )}


      {/* PURCHASE DETAILS */}
      <div className="card">

        <h3>Purchase Details</h3>

        {rows.length === 0 ? (

          <p className="empty">
            No purchase records found.
          </p>

        ) : (

          <div className="table-wrap">

            <table>

              <thead>

                <tr>
                  <th>Transaction ID</th>
                  <th>Vendor</th>
                  <th>Brand</th>
                  <th>Category</th>
                  <th>Type</th>
                  <th>Unit</th>
                  <th>Quantity</th>
                  <th>Amount</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>

              </thead>

              <tbody>

                {rows.map((r, i) => (

                  <tr
                    key={
                      r.purchaseId ||
                      r.transactionId ||
                      i
                    }
                  >

                    <td>{r.transactionId}</td>

                    <td>{r.vendorName}</td>

                    <td>{r.brandName}</td>

                    <td>{r.materialCategoryId}</td>

                    <td>{r.materialTypeId}</td>

                    <td>{r.unitId}</td>

                    <td>{r.quantity}</td>

                    <td>
                      ₹
                      {Number(
                        r.purchaseAmount || 0
                      ).toFixed(2)}
                    </td>

                    <td>{r.purchaseDate}</td>

                    <td>
                      <span className="status">
                        {r.status || "SUCCESS"}
                      </span>
                    </td>

                  </tr>

                ))}

              </tbody>

            </table>

          </div>

        )}

      </div>

    </section>
  );
}