import React from "react";
export default function Home({setPage}){
 return <section>
  <h2>Inventory Management System</h2><p className="subtitle">Manage material purchases and view purchase details.</p>
  <div className="home-grid">
   <div className="card"><h3>Purchase Entry</h3><p>Add a new material purchase.</p><button className="primary" onClick={()=>setPage("purchase")}>Open Purchase Entry</button></div>
   <div className="card"><h3>Purchase Report</h3><p>View purchases by vendor and date.</p><button className="primary" onClick={()=>setPage("report")}>Open Purchase Report</button></div>
   <div className="card"><h3>Service Health</h3><p>Check Inventory, Material and Vendor services.</p><button className="secondary" onClick={()=>setPage("health")}>Check Status</button></div>
  </div>
  <div className="card"><h3>Application Flow</h3><p>React UI → Inventory Service → Material / Vendor Services → MySQL</p></div>
 </section>;
}