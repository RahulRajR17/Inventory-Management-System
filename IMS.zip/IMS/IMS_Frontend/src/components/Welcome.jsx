import React from "react";

export default function Welcome({ onLogin }) {
  return (
    <div className="welcome-page">

      <div className="welcome-card">

        <div className="welcome-logo">
          IMS
        </div>

        <div className="welcome-badge">
          Inventory Management System
        </div>

        <h1>
          Welcome to Inventory Management
          <span> System</span>
        </h1>

        <p>
          Manage material purchases, vendors and reports
          through a simple and centralized system.
        </p>

        <div className="welcome-features">
          <div>
            <strong>Purchase Entry</strong>
            <span>Add and manage purchases</span>
          </div>

          <div>
            <strong>Purchase Reports</strong>
            <span>View saved purchase records</span>
          </div>

          <div>
            <strong>Service Health</strong>
            <span>Monitor backend services</span>
          </div>
        </div>

        <button
          className="welcome-login-btn"
          onClick={onLogin}
        >
          Continue as Administrator →
        </button>

        <div className="welcome-footer">
          Secure Admin Access
        </div>

      </div>

    </div>
  );
}