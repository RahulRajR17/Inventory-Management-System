import React, { useState } from "react";

const ADMIN_ID = "admin";
const ADMIN_PASSWORD = "admin";

export default function Login({ onLogin, onBack }) {

  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");

  function submit(e) {

    e.preventDefault();

    setError("");

    if (!userId.trim()) {
      setError("Please enter User ID.");
      return;
    }

    if (!password) {
      setError("Please enter Password.");
      return;
    }

    if (
      userId === ADMIN_ID &&
      password === ADMIN_PASSWORD
    ) {
      onLogin();
      return;
    }

    setError("Invalid User ID or Password.");
  }


  return (
    <div className="auth-page">

      <div className="login-container">

        {/* Left branding */}
        <div className="login-brand-panel">

          <div className="auth-brand">

            <div className="auth-brand-logo">
              IMS
            </div>

            <div>
              <strong>Inventory Management</strong>
              <span>System</span>
            </div>

          </div>


          <div className="login-brand-content">

            <span className="auth-label">
              ADMIN PORTAL
            </span>

            <h1>
              Everything you need
              <br />
              to manage <span>inventory.</span>
            </h1>

            <p>
              Manage purchases, vendors and reports
              through one centralized system.
            </p>

          </div>

        </div>


        {/* Login form */}
        <div className="login-form-panel">

          <div className="login-form-content">

            <div className="login-icon">
              ⇥
            </div>

            <span className="welcome-small">
              ADMINISTRATION
            </span>

            <h2>
              Sign in to continue
            </h2>

            <p className="login-description">
              Enter your administrator credentials.
            </p>


            <form onSubmit={submit}>

              <label className="modern-label">
                User ID

                <div className="input-wrapper">

                  <span>♙</span>

                  <input
                    type="text"
                    value={userId}
                    onChange={(e) =>
                      setUserId(e.target.value)
                    }
                    placeholder="Enter your User ID"
                  />

                </div>

              </label>


              <label className="modern-label">
                Password

                <div className="input-wrapper">

                  <span>●</span>

                  <input
                    type="password"
                    value={password}
                    onChange={(e) =>
                      setPassword(e.target.value)
                    }
                    placeholder="Enter your password"
                  />

                </div>

              </label>


              {error && (
                <div className="login-error">
                  {error}
                </div>
              )}


              <button
                type="submit"
                className="auth-primary-button login-submit"
              >
                Sign In
                <span>→</span>
              </button>

            </form>



            <div className="login-note">
              Administrator access only
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}