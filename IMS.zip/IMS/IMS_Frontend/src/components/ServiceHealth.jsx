import React,{useCallback,useEffect,useState} from "react";
import {api} from "../api";
export default function ServiceHealth(){
 const [services,setServices]=useState([]),[loading,setLoading]=useState(false);
 const check=useCallback(async()=>{setLoading(true);setServices(await api.health());setLoading(false)},[]);
 useEffect(()=>{check()},[check]);
 return <section><div className="page-title-row"><div><h2>Service Health</h2><p className="subtitle">Check whether the backend services are running.</p></div><button className="secondary" onClick={check} disabled={loading}>{loading?"Checking...":"Refresh"}</button></div>
  <div className="health-list">{services.map(s=><div className="card health-row" key={s.name}><div className={s.online?"health-icon online":"health-icon offline"}>{s.online?"✓":"!"}</div><div><h3>{s.name}</h3><b className={s.online?"online-text":"offline-text"}>{s.online?"Available":"Unavailable"}</b><p>{s.detail}</p></div></div>)}</div>
  <div className="card"><h3>Backend URLs</h3><ul className="url-list"><li>Inventory: http://localhost:8083</li><li>Material: http://localhost:8082</li><li>Vendor: http://localhost:8087</li></ul></div>
 </section>;
}