import React from "react";

export default function Header({ page, setPage, onLogout }) {
  return (
    <header className="header">

      <div className="header-content">

        <div className="brand">

          <div className="brand-box">
            IMS
          </div>

          <div>
            <h1>Inventory Management System</h1>
            <p>Material Purchase Management</p>
          </div>

        </div>

        <nav>

          <button
            className={`nav-link ${page === "home" ? "active" : ""}`}
            onClick={() => setPage("home")}
          >
            Home
          </button>

          <button
            className={`nav-link ${page === "purchase" ? "active" : ""}`}
            onClick={() => setPage("purchase")}
          >
            Purchase Entry
          </button>

          <button
            className={`nav-link ${page === "report" ? "active" : ""}`}
            onClick={() => setPage("report")}
          >
            Purchase Report
          </button>

          <button
            className={`nav-link ${page === "health" ? "active" : ""}`}
            onClick={() => setPage("health")}
          >
            Service Health
          </button>

          <button
            className="logout-button"
            onClick={onLogout}
          >
            Logout
          </button>

        </nav>

      </div>

    </header>
  );
}