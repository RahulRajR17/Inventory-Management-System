import React from "react";

export default function Sidebar({ page, setPage, onLogout }) {
  return (
    <aside className="sidebar">

      <div className="sidebar-brand">
        <div className="sidebar-logo">IMS</div>

        <div>
          <h2>Inventory</h2>
          <span>Management System</span>
        </div>
      </div>

      <div className="menu-title">MAIN MENU</div>

      <nav className="sidebar-menu">

        <button
          className={page === "home" ? "sidebar-item active" : "sidebar-item"}
          onClick={() => setPage("home")}
        >
          <span className="menu-icon">⌂</span>
          <span>Dashboard</span>
        </button>

        <button
          className={page === "purchase" ? "sidebar-item active" : "sidebar-item"}
          onClick={() => setPage("purchase")}
        >
          <span className="menu-icon">＋</span>
          <span>Purchase Entry</span>
        </button>

        <button
          className={page === "report" ? "sidebar-item active" : "sidebar-item"}
          onClick={() => setPage("report")}
        >
          <span className="menu-icon">▤</span>
          <span>Purchase Report</span>
        </button>

        <button
          className={page === "health" ? "sidebar-item active" : "sidebar-item"}
          onClick={() => setPage("health")}
        >
          <span className="menu-icon">♥</span>
          <span>Service Health</span>
        </button>

      </nav>

      <div className="sidebar-bottom">

        <div className="admin-card">
          <div className="admin-avatar">A</div>

          <div>
            <strong>Administrator</strong>
            <small>Admin</small>
          </div>
        </div>

        <button className="logout-button" onClick={onLogout}>
          ↪ Logout
        </button>

      </div>

    </aside>
  );
}