import React,{useEffect,useState} from "react";
import {api} from "../api";
const empty={vendorName:"",materialCategoryId:"",materialTypeId:"",brandName:"",unitId:"",quantity:"",purchaseAmount:"",purchaseDate:""};
export default function PurchaseEntry(){
 const [form,setForm]=useState(empty),[vendors,setVendors]=useState([]),[categories,setCategories]=useState([]),[types,setTypes]=useState([]),[units,setUnits]=useState([]),[message,setMessage]=useState(""),[error,setError]=useState(""),[loading,setLoading]=useState(true),[saving,setSaving]=useState(false);
 useEffect(()=>{Promise.all([api.getVendors(),api.getCategories()]).then(([v,c])=>{setVendors(v||[]);setCategories(c||[])}).catch(e=>setError(e.message)).finally(()=>setLoading(false))},[]);
 const update=(f,v)=>setForm(x=>({...x,[f]:v}));
 async function categoryChanged(id){setForm(x=>({...x,materialCategoryId:id,materialTypeId:"",unitId:""}));setTypes([]);setUnits([]);setMessage("");setError("");if(!id)return;try{const r=await api.getUnitAndTypeList(id);setTypes(r?.materialTypeList||[]);setUnits(r?.unitList||[])}catch(e){setError(e.message)}}
 async function save(e){e.preventDefault();setMessage("");setError("");
  if(Object.values(form).some(v=>v==="")){setError("Please fill all required fields.");return}
  setSaving(true);try{const r=await api.addPurchaseDetail({...form,quantity:Number(form.quantity),purchaseAmount:Number(form.purchaseAmount)});
   setMessage(`${r?.message||"Purchase details added successfully"}${r?.purchase?.transactionId?` | Transaction ID: ${r.purchase.transactionId}`:""}`);
   setForm(empty);setTypes([]);setUnits([]);
  }catch(e){setError(e.message)}finally{setSaving(false)}
 }
 return <section><h2>Purchase Entry</h2><p className="subtitle">Enter the details of a new material purchase.</p>
  <form className="card" onSubmit={save}><div className="form-grid">
   <label>Vendor *<select value={form.vendorName} onChange={e=>update("vendorName",e.target.value)} disabled={loading}><option value="">-- Select Vendor --</option>{vendors.map(v=><option key={v.vendorId} value={v.vendorName}>{v.vendorName}</option>)}</select></label>
   <label>Material Category *<select value={form.materialCategoryId} onChange={e=>categoryChanged(e.target.value)} disabled={loading}><option value="">-- Select Category --</option>{categories.map(c=><option key={c.categoryId} value={c.categoryId}>{c.categoryName}</option>)}</select></label>
   <label>Material Type *<select value={form.materialTypeId} onChange={e=>update("materialTypeId",e.target.value)} disabled={!form.materialCategoryId}><option value="">-- Select Type --</option>{types.map(t=><option key={t.typeId} value={t.typeId}>{t.typeName}</option>)}</select></label>
   <label>Unit *<select value={form.unitId} onChange={e=>update("unitId",e.target.value)} disabled={!form.materialCategoryId}><option value="">-- Select Unit --</option>{units.map(u=><option key={u.unitId} value={u.unitId}>{u.unitName}</option>)}</select></label>
   <label>Brand Name *<input value={form.brandName} onChange={e=>update("brandName",e.target.value)} placeholder="Enter brand name"/></label>
   <label>Quantity *<input type="number" min="1" value={form.quantity} onChange={e=>update("quantity",e.target.value)} placeholder="Enter quantity"/></label>
   <label>Purchase Amount *<input type="number" min="0" step="0.01" value={form.purchaseAmount} onChange={e=>update("purchaseAmount",e.target.value)} placeholder="Enter amount"/></label>
   <label>Purchase Date *<input type="date" value={form.purchaseDate} onChange={e=>update("purchaseDate",e.target.value)}/></label>
  </div><div className="button-row"><button type="button" className="secondary" onClick={()=>{setForm(empty);setTypes([]);setUnits([]);setMessage("");setError("")}}>Clear</button><button className="primary" disabled={saving}>{saving?"Saving...":"Save Purchase"}</button></div>
  {message&&<div className="success">{message}</div>}{error&&<div className="error">{error}</div>}</form>
 </section>;
}