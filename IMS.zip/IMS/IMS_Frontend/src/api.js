async function request(url, options={}){
  const response=await fetch(url,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const text=await response.text(); let data=null;
  try{data=text?JSON.parse(text):null}catch{data=text}
  if(!response.ok) throw new Error(data?.message||data?.error||`Request failed (${response.status})`);
  return data;
}
export const api={
  health:async()=>{
    const checks=[["Inventory Service","/api/inventory/health"],["Material Service","/api/material/health"],["Vendor Service","/api/vendor/"]];
    return Promise.all(checks.map(async([name,url])=>{try{
      const data=await request(url); return {name,online:true,detail:typeof data==="string"?data:"Running"};
    }catch(e){return {name,online:false,detail:e.message}}}));
  },
  getVendors:()=>request("/api/inventory/vendors"),
  getCategories:()=>request("/api/inventory/categories"),
  getUnitAndTypeList:id=>request("/api/inventory/getUnitAndTypeList",{method:"POST",body:JSON.stringify({materialCategoryId:id})}),
  addPurchaseDetail:p=>request("/api/inventory/addPurchaseDetail",{method:"POST",body:JSON.stringify(p)}),
  getPurchaseDetails:p=>request("/api/inventory/report/controller/getPurchaseDetails",{method:"POST",body:JSON.stringify(p)})
};