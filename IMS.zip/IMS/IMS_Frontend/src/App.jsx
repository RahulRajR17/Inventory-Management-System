import React, { useState } from "react";

import Sidebar from "./components/Sidebar";
import Welcome from "./components/Welcome";
import Login from "./components/Login";
import Home from "./components/Home";
import PurchaseEntry from "./components/PurchaseEntry";
import PurchaseReport from "./components/PurchaseReport";
import ServiceHealth from "./components/ServiceHealth";
import Footer from "./components/Footer";

export default function App() {

  const [page, setPage] = useState("welcome");
  const [loggedIn, setLoggedIn] = useState(false);

  // WELCOME PAGE
  if (!loggedIn && page === "welcome") {
    return (
      <Welcome
        onLogin={() => setPage("login")}
      />
    );
  }

  // LOGIN PAGE
  if (!loggedIn && page === "login") {
    return (
      <Login
        onLogin={() => {
          setLoggedIn(true);
          setPage("home");
        }}
      />
    );
  }

  // MAIN APPLICATION
  return (
    <div className="app-layout">

      <Sidebar
        page={page}
        setPage={setPage}
        onLogout={() => {
          setLoggedIn(false);
          setPage("welcome");
        }}
      />

      <div className="main-area">

        <main className="main-content">

          {page === "home" && (
            <Home setPage={setPage} />
          )}

          {page === "purchase" && (
            <PurchaseEntry />
          )}

          {page === "report" && (
            <PurchaseReport />
          )}

          {page === "health" && (
            <ServiceHealth />
          )}

        </main>

        <Footer />

      </div>

    </div>
  );
}