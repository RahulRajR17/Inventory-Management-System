import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins:[react()],
  server:{
    host:"localhost", port:5173,
    proxy:{
      "/api/inventory":{target:"http://localhost:8083",changeOrigin:true,rewrite:p=>p.replace(/^\/api\/inventory/,"")},
      "/api/material":{target:"http://localhost:8082",changeOrigin:true,rewrite:p=>p.replace(/^\/api\/material/,"")},
      "/api/vendor":{target:"http://localhost:8087",changeOrigin:true,rewrite:p=>p.replace(/^\/api\/vendor/,"")}
    }
  }
});