package com.training.test.bean;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.training.business.bean.MaterialTypeBean;
 class MaterialTypeBeanTest {

	 @Test
	    void testDefaultConstructorAndSettersGetters() {

	        MaterialTypeBean bean = new MaterialTypeBean();

	        bean.setTypeId("T001");
	        bean.setTypeName("Cement");
	        bean.setCategoryId("C001");

	        assertEquals("T001", bean.getTypeId());
	        assertEquals("Cement", bean.getTypeName());
	        assertEquals("C001", bean.getCategoryId());
	    }

	    @Test
	    void testParameterizedConstructor() {

	        MaterialTypeBean bean =
	                new MaterialTypeBean("T001", "Cement", "C001");

	        assertEquals("T001", bean.getTypeId());
	        assertEquals("Cement", bean.getTypeName());
	        assertEquals("C001", bean.getCategoryId());
	    }

	    @Test
	    void testToString() {

	        MaterialTypeBean bean =
	                new MaterialTypeBean("T001", "Cement", "C001");

	        String result = bean.toString();

	        assertNotNull(result);
	        assertTrue(result.contains("T001"));
	        assertTrue(result.contains("Cement"));
	        assertTrue(result.contains("C001"));
	    }
}
