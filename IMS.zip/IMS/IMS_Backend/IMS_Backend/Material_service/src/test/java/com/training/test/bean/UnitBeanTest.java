package com.training.test.bean;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.training.business.bean.UnitBean;

 class UnitBeanTest {

    @Test
    void testDefaultConstructorAndSettersGetters() {

        UnitBean bean = new UnitBean();

        bean.setUnitId("U001");
        bean.setUnitName("KG");
        bean.setCategoryId("C001");

        assertEquals("U001", bean.getUnitId());
        assertEquals("KG", bean.getUnitName());
        assertEquals("C001", bean.getCategoryId());
    }

    @Test
    void testParameterizedConstructor() {

        UnitBean bean = new UnitBean("U001", "KG", "C001");

        assertEquals("U001", bean.getUnitId());
        assertEquals("KG", bean.getUnitName());
        assertEquals("C001", bean.getCategoryId());
    }

    @Test
    void testToString() {

        UnitBean bean = new UnitBean("U001", "KG", "C001");

        String result = bean.toString();

        assertNotNull(result);
        assertTrue(result.contains("U001"));
        assertTrue(result.contains("KG"));
        assertTrue(result.contains("C001"));
    }

}
