package com.training.test.bean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.training.business.bean.MaterialCategoryBean;

 class MaterialCategoryBeanTest {
	 
	 @Test
	     void testDefaultConstructorAndSettersGetters() {

	        MaterialCategoryBean bean = new MaterialCategoryBean();

	        bean.setCategoryId("C101");
	        bean.setCategoryName("Metals");

	        assertEquals("C101", bean.getCategoryId());
	        assertEquals("Metals", bean.getCategoryName());
	    }

	    @Test
	     void testParameterizedConstructor() {

	        MaterialCategoryBean bean =
	                new MaterialCategoryBean("C101", "Metals");

	        assertEquals("C101", bean.getCategoryId());
	        assertEquals("Metals", bean.getCategoryName());
	    }

	    @Test
	     void testToString() {

	        MaterialCategoryBean bean =
	                new MaterialCategoryBean("C101", "Metals");

	        String result = bean.toString();

	        assertNotNull(result);

	        assertEquals(
	                "MaterialCategoryBean [categoryId=C101, categoryName=Metals]",
	                result);
	    }

}
