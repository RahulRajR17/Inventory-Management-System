package com.training.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.business.bean.MaterialCategoryBean;
import com.training.controller.MaterialController;
import com.training.service.MaterialService;

@WebMvcTest(MaterialController.class)
 class MaterialControllerTest {

    private static final Logger logger = LoggerFactory.getLogger(MaterialControllerTest.class);

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MaterialService materialServiceMock;

    @Test
    void healthMaterialControllerTest() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders.get("/health"))
                .andExpect(status().isOk())
                .andExpect(content().string("Material Service is UP"));
    }
    
    @Test
     void testHome() {

        MaterialController controller = new MaterialController();

        assertEquals(
                "Material Service deployed successfully",
                controller.home());
    }
    
    @Test
     void testGetMaterialCategories() throws Exception {

        MaterialController controller = new MaterialController();

        MaterialService service = Mockito.mock(MaterialService.class);

        List<MaterialCategoryBean> list = new ArrayList<>();

        when(service.getMaterialCategories()).thenReturn(list);

        Field field =
                MaterialController.class.getDeclaredField("materialService");
        field.setAccessible(true);
        field.set(controller, service);

        ResponseEntity<List<MaterialCategoryBean>> response =
                controller.getMaterialCategories();

        assertEquals(200, response.getStatusCodeValue());
    }

}