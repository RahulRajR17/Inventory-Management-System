package com.training.test.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.training.entity.MaterialCategoryEntity;
import com.training.entity.UnitEntity;

class UnitEntityTest {
	@Test
     void testDefaultConstructorAndSettersGetters() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();

        UnitEntity entity = new UnitEntity();

        entity.setUnitId("U001");
        entity.setUnitName("Kilogram");
        entity.setMaterialCategoryEntity(category);

        assertEquals("U001", entity.getUnitId());
        assertEquals("Kilogram", entity.getUnitName());
        assertEquals(category, entity.getMaterialCategoryEntity());
    }

    @Test
     void testParameterizedConstructor() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();

        UnitEntity entity =
                new UnitEntity("U001", "Kilogram", category);

        assertEquals("U001", entity.getUnitId());
        assertEquals("Kilogram", entity.getUnitName());
        assertEquals(category, entity.getMaterialCategoryEntity());
    }

    @Test
     void testToString() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();

        UnitEntity entity =
                new UnitEntity("U001", "Kilogram", category);

        String result = entity.toString();

        assertNotNull(result);

        assertEquals(
            "UnitEntity [unitId=U001, unitName=KilogrammaterialCategoryEntity"
                    + category + "]",
            result
        );
    }

}
