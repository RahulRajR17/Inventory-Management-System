package com.training.test.entity;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.training.entity.MaterialCategoryEntity;
import com.training.entity.MaterialTypeEntity;

 class MaterialTypeEntityTest {
	@Test
    void testDefaultConstructorAndSettersGetters() {

        MaterialTypeEntity entity = new MaterialTypeEntity();
        MaterialCategoryEntity category = new MaterialCategoryEntity();

        entity.setTypeId("T001");
        entity.setTypeName("Cement");
        entity.setMaterialCategoryEntity(category);

        assertEquals("T001", entity.getTypeId());
        assertEquals("Cement", entity.getTypeName());
        assertEquals(category, entity.getMaterialCategoryEntity());
    }

    @Test
    void testParameterizedConstructor() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();

        MaterialTypeEntity entity =
                new MaterialTypeEntity("T001", "Cement", category);

        assertEquals("T001", entity.getTypeId());
        assertEquals("Cement", entity.getTypeName());
        assertEquals(category, entity.getMaterialCategoryEntity());
    }

    @Test
    void testToString() {

        MaterialCategoryEntity category = new MaterialCategoryEntity();

        MaterialTypeEntity entity =
                new MaterialTypeEntity("T001", "Cement", category);

        String result = entity.toString();

        assertNotNull(result);
        assertTrue(result.contains("T001"));
        assertTrue(result.contains("Cement"));
    }

}
