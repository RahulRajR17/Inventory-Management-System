package com.training.test;


import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;

import com.training.ServletInitializer;

class ServletInitializerTest {

	 static class TestServletInitializer extends ServletInitializer {
	        public SpringApplicationBuilder callConfigure(SpringApplicationBuilder builder) {
	            return super.configure(builder);
	        }
	    }

	    @Test
	     void testConfigure() {

	        TestServletInitializer initializer = new TestServletInitializer();

	        SpringApplicationBuilder builder =
	                new SpringApplicationBuilder();

	        assertNotNull(initializer.callConfigure(builder));
	    }
}
