package com.training.test.service;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.training.business.bean.MaterialTypeBean;
import com.training.dao.MaterialTypeDAO;
import com.training.entity.MaterialCategoryEntity;
import com.training.entity.MaterialTypeEntity;
import com.training.service.MaterialTypeServiceImpl;

 class MaterialTypeServiceTest {
	 
	 private MaterialTypeServiceImpl service;

	    @Mock
	    private MaterialTypeDAO materialTypeDAO;

	    @BeforeEach
	    void setUp() throws Exception {

	        MockitoAnnotations.openMocks(this);

	        service = new MaterialTypeServiceImpl();

	        Field field =
	                MaterialTypeServiceImpl.class.getDeclaredField("materialTypeDAO");
	        field.setAccessible(true);
	        field.set(service, materialTypeDAO);
	    }

	    @Test
	    void testGetMaterialTypes() {

	        MaterialCategoryEntity category = new MaterialCategoryEntity();
	        category.setCategoryId("C101");

	        MaterialTypeEntity entity = new MaterialTypeEntity();
	        entity.setTypeId("T101");
	        entity.setTypeName("Steel");
	        entity.setMaterialCategoryEntity(category);

	        when(materialTypeDAO.findAll())
	                .thenReturn(Arrays.asList(entity));

	        List<MaterialTypeBean> result = service.getMaterialTypes();

	        assertEquals(1, result.size());
	        assertEquals("T101", result.get(0).getTypeId());
	        assertEquals("Steel", result.get(0).getTypeName());
	        assertEquals("C101", result.get(0).getCategoryId());
	    }

	    @Test
	    void testGetMaterialTypesBasedOnCategoryId() {

	        MaterialCategoryEntity category = new MaterialCategoryEntity();
	        category.setCategoryId("C101");

	        MaterialTypeEntity entity = new MaterialTypeEntity();
	        entity.setTypeId("T101");
	        entity.setTypeName("Steel");
	        entity.setMaterialCategoryEntity(category);

	        when(materialTypeDAO
	                .findByMaterialCategoryEntityCategoryId("C101"))
	                .thenReturn(Arrays.asList(entity));

	        List<MaterialTypeBean> result =
	                service.getMaterialTypesBasedOnCategoryId("C101");

	        assertEquals(1, result.size());
	        assertEquals("T101", result.get(0).getTypeId());
	        assertEquals("Steel", result.get(0).getTypeName());
	        assertEquals("C101", result.get(0).getCategoryId());
	    }

}
