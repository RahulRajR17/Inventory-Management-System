package com.training.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.training.business.bean.UnitBean;
import com.training.dao.UnitDAO;
import com.training.entity.MaterialCategoryEntity;
import com.training.entity.UnitEntity;
import com.training.service.UnitServiceImpl;

 class UnitServiceImplTest {
	 
	 private UnitServiceImpl service;

	    @Mock
	    private UnitDAO unitDAO;

	    @BeforeEach
	    void setUp() throws Exception {
	        MockitoAnnotations.openMocks(this);

	        service = new UnitServiceImpl();

	        Field field = UnitServiceImpl.class.getDeclaredField("unitDAO");
	        field.setAccessible(true);
	        field.set(service, unitDAO);
	    }

	    @Test
	    void testGetUnits() {

	        MaterialCategoryEntity category =
	                new MaterialCategoryEntity("C001", "Electrical");

	        UnitEntity entity = new UnitEntity();
	        entity.setUnitId("U001");
	        entity.setUnitName("Kg");
	        entity.setMaterialCategoryEntity(category);

	        when(unitDAO.findAll()).thenReturn(Arrays.asList(entity));

	        List<UnitBean> result = service.getUnits();

	        assertEquals(1, result.size());
	        assertEquals("U001", result.get(0).getUnitId());
	        assertEquals("Kg", result.get(0).getUnitName());
	        assertEquals("C001", result.get(0).getCategoryId());
	    }

	    @Test
	    void testGetUnitsBasedOnCategoryId() {

	        MaterialCategoryEntity category =
	                new MaterialCategoryEntity("C001", "Electrical");

	        UnitEntity entity = new UnitEntity();
	        entity.setUnitId("U001");
	        entity.setUnitName("Kg");
	        entity.setMaterialCategoryEntity(category);

	        when(unitDAO.findByMaterialCategoryEntityCategoryId("C001"))
	                .thenReturn(Arrays.asList(entity));

	        List<UnitBean> result =
	                service.getUnitsBasedOnCategoryId("C001");

	        assertEquals(1, result.size());
	        assertEquals("U001", result.get(0).getUnitId());
	        assertEquals("Kg", result.get(0).getUnitName());
	        assertEquals("C001", result.get(0).getCategoryId());
	    }
	    
	    @Test
	    void testGetUnitsEmpty() {
	        when(unitDAO.findAll()).thenReturn(List.of());

	        List<UnitBean> result = service.getUnits();

	        assertEquals(0, result.size());
	    }

	    @Test
	    void testGetUnitsBasedOnCategoryIdEmpty() {
	        when(unitDAO.findByMaterialCategoryEntityCategoryId("C001"))
	                .thenReturn(List.of());

	        List<UnitBean> result =
	                service.getUnitsBasedOnCategoryId("C001");

	        assertEquals(0, result.size());
	    }

}
