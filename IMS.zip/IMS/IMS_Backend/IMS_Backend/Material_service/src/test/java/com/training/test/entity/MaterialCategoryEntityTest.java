package com.training.test.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.training.entity.MaterialCategoryEntity;

 class MaterialCategoryEntityTest {
	 
	 @Test
	     void testDefaultConstructorAndSettersGetters() {

	        MaterialCategoryEntity entity = new MaterialCategoryEntity();

	        entity.setCategoryId("C101");
	        entity.setCategoryName("Metals");

	        assertEquals("C101", entity.getCategoryId());
	        assertEquals("Metals", entity.getCategoryName());
	    }

	    @Test
	     void testParameterizedConstructor() {

	        MaterialCategoryEntity entity =
	                new MaterialCategoryEntity("C101", "Metals");

	        assertEquals("C101", entity.getCategoryId());
	        assertEquals("Metals", entity.getCategoryName());
	    }

	    @Test
	     void testToString() {

	        MaterialCategoryEntity entity =
	                new MaterialCategoryEntity("C101", "Metals");

	        String result = entity.toString();

	        assertNotNull(result);
	        assertEquals(
	                "MaterialCategoryEntity [categoryId=C101, categoryName=Metals]",
	                result);
	    }

}
