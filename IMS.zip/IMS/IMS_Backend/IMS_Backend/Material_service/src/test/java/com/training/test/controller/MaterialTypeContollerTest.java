package com.training.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.training.business.bean.MaterialTypeBean;
import com.training.controller.MaterialTypeContoller;
import com.training.service.MaterialTypeService;

 class MaterialTypeContollerTest {
	 
	 private MaterialTypeContoller controller;

	    @Mock
	    private MaterialTypeService materialTypeService;

	    @BeforeEach
	    void setUp() throws Exception {

	        MockitoAnnotations.openMocks(this);

	        controller = new MaterialTypeContoller();

	        Field field =
	                MaterialTypeContoller.class.getDeclaredField("materialTypeService");
	        field.setAccessible(true);
	        field.set(controller, materialTypeService);
	    }

	    @Test
	    void testGetTypeDetails() {

	        MaterialTypeBean bean = new MaterialTypeBean();
	        bean.setTypeId("T001");
	        bean.setTypeName("Steel");
	        bean.setCategoryId("C001");

	        when(materialTypeService.getMaterialTypes())
	                .thenReturn(Arrays.asList(bean));

	        ResponseEntity<List<MaterialTypeBean>> response =
	                controller.getTypeDetails();

	        assertEquals(200, response.getStatusCodeValue());
	        assertEquals(1, response.getBody().size());
	        assertEquals("T001", response.getBody().get(0).getTypeId());
	    }

	    @Test
	    void testGetTypesBasedOnCategoryId() {

	        MaterialTypeBean bean = new MaterialTypeBean();
	        bean.setTypeId("T001");
	        bean.setTypeName("Steel");
	        bean.setCategoryId("C001");

	        when(materialTypeService.getMaterialTypesBasedOnCategoryId("C001"))
	                .thenReturn(Arrays.asList(bean));

	        ResponseEntity<List<MaterialTypeBean>> response =
	                controller.getTypesBasedOnCategoryId("C001");

	        assertEquals(200, response.getStatusCodeValue());
	        assertEquals(1, response.getBody().size());
	        assertEquals("C001", response.getBody().get(0).getCategoryId());
	    }

}
