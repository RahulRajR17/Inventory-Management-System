package com.training;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;

class InventoryManagementSystemApplicationTest {

    @Test
    void testApplicationInstance() {
        InventoryManagementSystemApplication app =
                new InventoryManagementSystemApplication();

        assertNotNull(app);
    }

    @Test
    void testConfigure() {

        InventoryManagementSystemApplication app =
                new InventoryManagementSystemApplication();

        SpringApplicationBuilder builder =
                new SpringApplicationBuilder();

        assertNotNull(app.configure(builder));
    }
}