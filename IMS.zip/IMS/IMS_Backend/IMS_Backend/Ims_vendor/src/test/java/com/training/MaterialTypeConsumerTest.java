package com.training;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.training.business.bean.MaterialTypeBean;
import com.training.exceptions.MicroServiceException;
import com.training.web.client.MaterialTypeConsumer;

 class MaterialTypeConsumerTest {
	 
	 @Test
	    void testGetMaterialTypeBeanList() throws Exception {

	        MaterialTypeConsumer consumer = new MaterialTypeConsumer();

	        RestTemplate restTemplate = mock(RestTemplate.class);

	        MaterialTypeBean bean = new MaterialTypeBean();
	        bean.setTypeId("1");
	        bean.setTypeName("Type1");

	        ResponseEntity<MaterialTypeBean[]> response =
	                ResponseEntity.ok(new MaterialTypeBean[] { bean });

	        when(restTemplate.getForEntity(anyString(),
	                eq(MaterialTypeBean[].class)))
	                .thenReturn(response);

	        ReflectionTestUtils.setField(consumer, "restTemplate", restTemplate);
	        ReflectionTestUtils.setField(consumer, "serviceURL", "http://localhost");
	        ReflectionTestUtils.setField(consumer, "apiURL", "/types");

	        List<MaterialTypeBean> result = consumer.getMaterialTypeBeanList();

	        assertNotNull(result);
	        assertEquals(1, result.size());
	    }

	    @Test
	    void testGetCategoryTypeMap() throws Exception {

	        MaterialTypeConsumer consumer = new MaterialTypeConsumer();

	        MaterialTypeBean bean = new MaterialTypeBean();
	        bean.setTypeId("1");
	        bean.setTypeName("Type1");

	        ReflectionTestUtils.setField(
	                consumer,
	                "materialTypeBeanList",
	                List.of(bean));

	        Map<String, String> result = consumer.getCategoryTypeMap();

	        assertNotNull(result);
	        assertEquals("Type1", result.get("1"));
	    }

	    @Test
	    void testHitGetTypesBasedOnCategoryId() throws Exception {

	        MaterialTypeConsumer consumer = new MaterialTypeConsumer();

	        RestTemplate restTemplate = mock(RestTemplate.class);

	        MaterialTypeBean bean = new MaterialTypeBean();
	        bean.setTypeId("1");
	        bean.setTypeName("Type1");

	        ResponseEntity<MaterialTypeBean[]> response =
	                ResponseEntity.ok(new MaterialTypeBean[] { bean });

	        when(restTemplate.getForEntity(anyString(),
	                eq(MaterialTypeBean[].class)))
	                .thenReturn(response);

	        ReflectionTestUtils.setField(consumer, "restTemplate", restTemplate);
	        ReflectionTestUtils.setField(consumer, "serviceURL", "http://localhost");
	        ReflectionTestUtils.setField(consumer, "apiURLByCategoryId", "/category/");

	        List<MaterialTypeBean> result =
	                consumer.hitGetTypesBasedOnCategoryId("100");

	        assertNotNull(result);
	        assertEquals(1, result.size());
	    }

	    @Test
	    void testHitGetTypesBasedOnCategoryIdNull() throws Exception {

	        MaterialTypeConsumer consumer = new MaterialTypeConsumer();

	        assertNull(
	                consumer.hitGetTypesBasedOnCategoryId(null));
	    }

	    @Test
	    void testHitGetTypesBasedOnCategoryIdException() {

	        MaterialTypeConsumer consumer = new MaterialTypeConsumer();

	        RestTemplate restTemplate = mock(RestTemplate.class);

	        when(restTemplate.getForEntity(anyString(),
	                eq(MaterialTypeBean[].class)))
	                .thenThrow(new RuntimeException());

	        ReflectionTestUtils.setField(consumer, "restTemplate", restTemplate);
	        ReflectionTestUtils.setField(consumer, "serviceURL", "http://localhost");
	        ReflectionTestUtils.setField(consumer, "apiURLByCategoryId", "/category/");

	        assertThrows(
	                MicroServiceException.class,
	                () -> consumer.hitGetTypesBasedOnCategoryId("100"));
	    }

}
