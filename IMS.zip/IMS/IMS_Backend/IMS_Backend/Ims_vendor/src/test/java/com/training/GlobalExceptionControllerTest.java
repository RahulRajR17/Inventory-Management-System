package com.training;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.training.exceptions.MicroServiceException;
import com.training.web.controller.GlobalExceptionController;
import com.training.web.controller.GlobalExceptionController.ErrorResponse;

 class GlobalExceptionControllerTest {
	 private final GlobalExceptionController controller =
	            new GlobalExceptionController();

	 @Test
	 void testHandleAllException() {

	     MicroServiceException ex = new MicroServiceException();

	     ResponseEntity<ErrorResponse> response =
	             controller.handleAllException(ex);

	     assertEquals(400, response.getStatusCodeValue());
	     assertEquals("ERROR", response.getBody().getStatus());
	     assertEquals(
	         "Service is not up and running. Please contact your administrator.",
	         response.getBody().getMessage());
	 }

	    @Test
	    void testHandleValidationException_MethodArgumentNotValidException()
	             {

	        BeanPropertyBindingResult result =
	                new BeanPropertyBindingResult(new Object(), "obj");

	        result.addError(
	                new FieldError("obj", "name", "must not be blank"));

	        MethodArgumentNotValidException ex =
	                new MethodArgumentNotValidException(null, result);

	        ResponseEntity<GlobalExceptionController.ErrorResponse> response =
	                controller.handleValidationException(ex);

	        assertEquals(400, response.getStatusCodeValue());
	    }

	    @Test
	    void testHandleValidationException_BindException() {

	        BeanPropertyBindingResult result =
	                new BeanPropertyBindingResult(new Object(), "obj");

	        result.addError(
	                new FieldError("obj", "quantity", "invalid"));

	        BindException ex = new BindException(result);

	        ResponseEntity<GlobalExceptionController.ErrorResponse> response =
	                controller.handleValidationException(ex);

	        assertEquals(400, response.getStatusCodeValue());
	    }

	    @Test
	    void testErrorResponseGetters() {

	        GlobalExceptionController.ErrorResponse response =
	                new GlobalExceptionController.ErrorResponse(
	                        "ERROR",
	                        "Message");

	        assertEquals("ERROR", response.getStatus());
	        assertEquals("Message", response.getMessage());
	    }

}
