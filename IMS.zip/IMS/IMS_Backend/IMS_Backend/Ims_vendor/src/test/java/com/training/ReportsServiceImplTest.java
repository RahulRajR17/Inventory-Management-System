package com.training;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.PurchaseBean;
import com.training.dao.ReportsDataAccess;
import com.training.service.ReportsServiceImpl;

@ExtendWith(MockitoExtension.class)
 class ReportsServiceImplTest {
	
	@Mock
    private ReportsDataAccess reportsDataAccess;

    @InjectMocks
    private ReportsServiceImpl reportsServiceImpl;

    @Test
    void testGetVendorWisePurchaseDetails() {

        List<PurchaseBean> purchaseList = new ArrayList<>();

        PurchaseBean bean = new PurchaseBean();
        purchaseList.add(bean);

        when(reportsDataAccess.getVendorWisePurchaseDetails(
                org.mockito.ArgumentMatchers.any(),
                org.mockito.ArgumentMatchers.any(),
                org.mockito.ArgumentMatchers.anyString()))
                .thenReturn(purchaseList);

        List<PurchaseBean> result =
                reportsServiceImpl.getVendorWisePurchaseDetails(
                        Date.valueOf("2025-01-01"),
                        Date.valueOf("2025-01-31"),
                        "Vendor1");

        assertEquals(1, result.size());
    }

}
