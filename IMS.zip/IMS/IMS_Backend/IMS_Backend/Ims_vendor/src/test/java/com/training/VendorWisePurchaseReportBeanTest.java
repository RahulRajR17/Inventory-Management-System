package com.training;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;

import org.junit.jupiter.api.Test;

import com.training.business.bean.VendorWisePurchaseReportBean;

 class VendorWisePurchaseReportBeanTest {
	

    @Test
    void testBeanMethods() {

        Date fromDate = Date.valueOf("2026-01-01");
        Date toDate = Date.valueOf("2026-01-31");

        // Default constructor
        VendorWisePurchaseReportBean bean =
                new VendorWisePurchaseReportBean();

        bean.setFromDate(fromDate);
        bean.setToDate(toDate);
        bean.setVendorName("Vendor1");

        assertEquals(fromDate, bean.getFromDate());
        assertEquals(toDate, bean.getToDate());
        assertEquals("Vendor1", bean.getVendorName());

        assertNotNull(bean.toString());
    }

    @Test
    void testParameterizedConstructor() {

        Date fromDate = Date.valueOf("2026-01-01");
        Date toDate = Date.valueOf("2026-01-31");

        VendorWisePurchaseReportBean bean =
                new VendorWisePurchaseReportBean(
                        fromDate,
                        toDate,
                        "Vendor1");

        assertEquals(fromDate, bean.getFromDate());
        assertEquals(toDate, bean.getToDate());
        assertEquals("Vendor1", bean.getVendorName());
    }

}
