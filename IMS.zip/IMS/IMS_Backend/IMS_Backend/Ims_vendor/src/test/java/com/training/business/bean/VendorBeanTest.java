package com.training.business.bean;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

 class VendorBeanTest {

    @Test
     void testConstructor() {

        VendorBean bean = new VendorBean(
                "V001",
                "ABC Vendor",
                "Hyderabad",
                "John",
                "9876543210");

        assertEquals("V001", bean.getVendorId());
        assertEquals("ABC Vendor", bean.getVendorName());
        assertEquals("Hyderabad", bean.getVendorAddress());
        assertEquals("John", bean.getContactPerson());
        assertEquals("9876543210", bean.getContactNumber());
    }

    @Test
     void testSettersAndGetters() {

        VendorBean bean = new VendorBean();

        bean.setVendorId("V002");
        bean.setVendorName("XYZ Vendor");
        bean.setVendorAddress("Bangalore");
        bean.setContactPerson("David");
        bean.setContactNumber("9999999999");

        assertEquals("V002", bean.getVendorId());
        assertEquals("XYZ Vendor", bean.getVendorName());
        assertEquals("Bangalore", bean.getVendorAddress());
        assertEquals("David", bean.getContactPerson());
        assertEquals("9999999999", bean.getContactNumber());
    }

    @Test
     void testToString() {

        VendorBean bean = new VendorBean(
                "V001",
                "ABC Vendor",
                "Hyderabad",
                "John",
                "9876543210");

        String result = bean.toString();

        assertNotNull(result);
        assertTrue(result.contains("V001"));
        assertTrue(result.contains("ABC Vendor"));
    }
}