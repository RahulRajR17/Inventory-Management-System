package com.training;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;

import com.training.web.controller.ServletInitializer;

 class ServletInitializerTest  extends ServletInitializer {
	 public SpringApplicationBuilder callConfigure(SpringApplicationBuilder builder) {
	        return configure(builder);
	    }
	
	 @Test
	 void testConfigure() {
	     ServletInitializerTest initializer = new ServletInitializerTest();
	     SpringApplicationBuilder builder = new SpringApplicationBuilder();

	     assertNotNull(initializer.callConfigure(builder));
	 }

}
