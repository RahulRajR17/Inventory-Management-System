package com.training.web.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.training.business.bean.VendorBean;

 class VendorServiceConsumerTest {

    private VendorServiceConsumer consumer;

    @BeforeEach
    void setUp() {

        consumer = new VendorServiceConsumer();

        VendorBean vendor1 = new VendorBean(
                "1",
                "Vendor1",
                "Address1",
                "Person1",
                "9999999999");

        VendorBean vendor2 = new VendorBean(
                "2",
                "Vendor2",
                "Address2",
                "Person2",
                "8888888888");

        List<VendorBean> vendorList = Arrays.asList(vendor1, vendor2);

        ReflectionTestUtils.setField(
                consumer,
                "vendorBeanList",
                vendorList);
    }

    @Test
    void testGetVendorBeanList() throws Exception {

        List<VendorBean> result = consumer.getVendorBeanList();

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    void testGetVendorMap() {

        Map<String, VendorBean> result = consumer.getVendorMap();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.containsKey("Vendor1"));
    }

    @Test
    void testConstructor() {

        VendorServiceConsumer vendorConsumer =
                new VendorServiceConsumer();

        assertNotNull(vendorConsumer);
    }
}