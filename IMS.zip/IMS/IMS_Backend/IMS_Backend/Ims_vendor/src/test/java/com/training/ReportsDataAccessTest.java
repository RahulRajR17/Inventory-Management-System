package com.training;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.dao.ReportsDAO;
import com.training.dao.ReportsDataAccess;
import com.training.entity.PurchaseEntity;
import com.training.business.bean.PurchaseBean;

@ExtendWith(MockitoExtension.class)
 class ReportsDataAccessTest {
	
	 @Mock
	    private ReportsDAO reportsDAO;

	    @InjectMocks
	    private ReportsDataAccess reportsDataAccess;

	    @Test
	    void testGetVendorWisePurchaseDetails() {

	        PurchaseEntity entity = new PurchaseEntity();

	        entity.setPurchaseId(1);
	        entity.setTransactionId("100");
	        entity.setVendorName("Vendor1");
	        entity.setMaterialCategoryId("100");
	        entity.setMaterialTypeId("20");
	        entity.setBrandName("BrandA");
	        entity.setUnitId("5");
	        entity.setQuantity(50);
	        entity.setPurchaseAmount(5000.0);
	        entity.setStatus("ACTIVE");

	        List<PurchaseEntity> entityList =
	                Arrays.asList(entity);

	        when(reportsDAO.getVendorWisePurchaseDetails(
	                org.mockito.ArgumentMatchers.any(),
	                org.mockito.ArgumentMatchers.any(),
	                org.mockito.ArgumentMatchers.anyString()))
	                .thenReturn(entityList);

	        List<PurchaseBean> result =
	                reportsDataAccess.getVendorWisePurchaseDetails(
	                        Date.valueOf("2025-01-01"),
	                        Date.valueOf("2025-01-31"),
	                        "Vendor1");

	        assertEquals(1, result.size());

	        PurchaseBean bean = result.get(0);

	        assertEquals(1, bean.getPurchaseId());
	        assertEquals("Vendor1", bean.getVendorName());
	        assertEquals("BrandA", bean.getBrandName());
	        assertEquals("ACTIVE", bean.getStatus());
	    }

}
