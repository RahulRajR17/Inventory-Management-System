package com.training;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.training.business.bean.PurchaseBean;
import com.training.business.bean.VendorWisePurchaseReportBean;
import com.training.service.ReportsService;
import com.training.web.controller.ReportsController;

 class ReportsControllerTest {
	 
	 @Mock
	    private ReportsService reportsService;

	    @InjectMocks
	    private ReportsController reportsController;

	    public ReportsControllerTest() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    void testGetPurchaseDetails() throws Exception {

	        VendorWisePurchaseReportBean bean =
	                new VendorWisePurchaseReportBean();

	        bean.setVendorName("Vendor1");

	        List<PurchaseBean> purchaseList = new ArrayList<>();

	        when(reportsService.getVendorWisePurchaseDetails(
	                bean.getFromDate(),
	                bean.getToDate(),
	                bean.getVendorName()))
	                .thenReturn(purchaseList);

	        ResponseEntity<List<PurchaseBean>> response =
	                reportsController.getPurchaseDetails(bean);

	        assertEquals(200, response.getStatusCodeValue());
	        assertEquals(purchaseList, response.getBody());
	    }

}
