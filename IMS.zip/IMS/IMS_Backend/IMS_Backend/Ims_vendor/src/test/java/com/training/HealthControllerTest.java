package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.controller.HealthController;
import com.training.web.controller.HomeController;

@SpringBootTest
 class HealthControllerTest {
	
	 @Autowired
	  private HomeController homeController;
	  @Test
	    void testHealth() {

	        HealthController controller = new HealthController();

	        String result = controller.health();

	        assertEquals("Inventory Service is UP", result);
	    }
	  
	  @Test
	    void testShowHomePage() {

	        var response = homeController.showHomePage();

	        assertEquals(
	            "Welcome to the Home Page!",
	            response.getBody().getMessage()
	        );
	    }

}
