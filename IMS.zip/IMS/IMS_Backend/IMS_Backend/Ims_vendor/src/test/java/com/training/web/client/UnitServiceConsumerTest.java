package com.training.web.client;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.training.business.bean.UnitBean;
import com.training.exceptions.MicroServiceException;


 class UnitServiceConsumerTest {

    @Test
    void testGetUnitBeanList() throws Exception {

        UnitServiceConsumer consumer = new UnitServiceConsumer();

        RestTemplate restTemplate = mock(RestTemplate.class);

        UnitBean bean = new UnitBean();
        bean.setUnitId("1");
        bean.setUnitName("KG");

        ResponseEntity<UnitBean[]> response =
                ResponseEntity.ok(new UnitBean[] { bean });

        when(restTemplate.getForEntity(
                anyString(),
                eq(UnitBean[].class)))
                .thenReturn(response);

        ReflectionTestUtils.setField(
                consumer,
                "restTemplate",
                restTemplate);

        ReflectionTestUtils.setField(
                consumer,
                "serviceURL",
                "http://localhost");

        ReflectionTestUtils.setField(
                consumer,
                "apiURL",
                "/units");

        List<UnitBean> result = consumer.getUnitBeanList();

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void testGetUnitMap() throws Exception {

        UnitServiceConsumer consumer = new UnitServiceConsumer();

        UnitBean bean = new UnitBean();
        bean.setUnitId("1");
        bean.setUnitName("KG");

        ReflectionTestUtils.setField(
                consumer,
                "unitBeanList",
                List.of(bean));

        Map<String, String> result =
                consumer.getUnitMap();

        assertNotNull(result);
        assertEquals("KG", result.get("1"));
    }

    @Test
    void testHitGetUnitsByCategoryId() throws Exception {

        UnitServiceConsumer consumer =
                new UnitServiceConsumer();

        RestTemplate restTemplate =
                mock(RestTemplate.class);

        UnitBean bean = new UnitBean();
        bean.setUnitId("1");
        bean.setUnitName("KG");

        ResponseEntity<UnitBean[]> response =
                ResponseEntity.ok(
                        new UnitBean[] { bean });

        when(restTemplate.getForEntity(
                anyString(),
                eq(UnitBean[].class)))
                .thenReturn(response);

        ReflectionTestUtils.setField(
                consumer,
                "restTemplate",
                restTemplate);

        ReflectionTestUtils.setField(
                consumer,
                "serviceURL",
                "http://localhost");

        ReflectionTestUtils.setField(
                consumer,
                "apiURLByCategoryId",
                "/category/");

        List<UnitBean> result =
                consumer.hitGetUnitsByCategoryId("100");

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void testHitGetUnitsByCategoryIdException() {

        UnitServiceConsumer consumer =
                new UnitServiceConsumer();

        RestTemplate restTemplate =
                mock(RestTemplate.class);

        when(restTemplate.getForEntity(
                anyString(),
                eq(UnitBean[].class)))
                .thenThrow(new RuntimeException());

        ReflectionTestUtils.setField(
                consumer,
                "restTemplate",
                restTemplate);

        ReflectionTestUtils.setField(
                consumer,
                "serviceURL",
                "http://localhost");

        ReflectionTestUtils.setField(
                consumer,
                "apiURLByCategoryId",
                "/category/");

        assertThrows(
                MicroServiceException.class,
                () -> consumer.hitGetUnitsByCategoryId("100"));
    }
}
