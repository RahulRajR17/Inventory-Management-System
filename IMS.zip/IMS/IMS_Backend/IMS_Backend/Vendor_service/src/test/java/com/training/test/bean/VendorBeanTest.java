package com.training.test.bean;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.training.business.bean.VendorBean;

  class VendorBeanTest {
    @Test
      void testDefaultConstructorAndSettersGetters() {

        VendorBean bean = new VendorBean();

        bean.setVendorId("V101");
        bean.setVendorName("ABC Vendor");
        bean.setVendorAddress("Hyderabad");
        bean.setContactPerson("Teju");
        bean.setContactNumber("9876543210");

        assertEquals("V101", bean.getVendorId());
        assertEquals("ABC Vendor", bean.getVendorName());
        assertEquals("Hyderabad", bean.getVendorAddress());
        assertEquals("Teju", bean.getContactPerson());
        assertEquals("9876543210", bean.getContactNumber());
    }

    @Test
     void testParameterizedConstructor() {

        VendorBean bean = new VendorBean(
                "V101",
                "ABC Vendor",
                "Hyderabad",
                "Teju",
                "9876543210");

        assertEquals("V101", bean.getVendorId());
        assertEquals("ABC Vendor", bean.getVendorName());
        assertEquals("Hyderabad", bean.getVendorAddress());
        assertEquals("Teju", bean.getContactPerson());
        assertEquals("9876543210", bean.getContactNumber());
    }

    @Test
    void testToString() {

        VendorBean bean = new VendorBean(
                "V101",
                "ABC Vendor",
                "Hyderabad",
                "Teju",
                "9876543210");

        String result = bean.toString();

        assertNotNull(result);
        assertEquals(
            "VendorBean [vendorId=V101, vendorName=ABC Vendor, vendorAddress=Hyderabad, contactPerson=Teju, contactNumber=9876543210]",
            result
        );
    }


}
