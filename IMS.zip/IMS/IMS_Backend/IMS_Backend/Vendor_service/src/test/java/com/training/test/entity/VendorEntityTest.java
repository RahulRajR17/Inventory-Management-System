package com.training.test.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.training.entity.VendorEntity;

class VendorEntityTest {
	
	 @Test
	    void testDefaultConstructorAndSettersGetters() {

	        VendorEntity entity = new VendorEntity();

	        entity.setVendorId("V101");
	        entity.setVendorName("ABC Vendor");
	        entity.setVendorAddress("Hyderabad");
	        entity.setContactPerson("Teju");
	        entity.setContactNumber("9876543210");

	        assertEquals("V101", entity.getVendorId());
	        assertEquals("ABC Vendor", entity.getVendorName());
	        assertEquals("Hyderabad", entity.getVendorAddress());
	        assertEquals("Teju", entity.getContactPerson());
	        assertEquals("9876543210", entity.getContactNumber());
	    }

	    @Test
	     void testParameterizedConstructor() {

	        VendorEntity entity = new VendorEntity(
	                "V101",
	                "ABC Vendor",
	                "Hyderabad",
	                "Teju",
	                "9876543210");

	        assertEquals("V101", entity.getVendorId());
	        assertEquals("ABC Vendor", entity.getVendorName());
	        assertEquals("Hyderabad", entity.getVendorAddress());
	        assertEquals("Teju", entity.getContactPerson());
	        assertEquals("9876543210", entity.getContactNumber());
	    }

	    @Test
	        void testToString() {

	        VendorEntity entity = new VendorEntity(
	                "V101",
	                "ABC Vendor",
	                "Hyderabad",
	                "Teju",
	                "9876543210");

	        assertNotNull(entity.toString());
	    }

}
